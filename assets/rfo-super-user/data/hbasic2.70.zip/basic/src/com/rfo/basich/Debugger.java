package com.rfo.basich;

/* Through BASIC! version v01.75.02, this file held the Application sub-class
 * that initialized the Application Crash Reports for Android (ACRA).
 * To reinstall the crash reporter, restore earlier versions of this file
 * and of the AndroidManifest.xml file. There is also a Preferences option
 * to disable crash reporting, found only in the V01.75.02 version of
 * the res/xml/settings.xml file.
 */

